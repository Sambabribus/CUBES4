package com.example.application.contracts;

import com.example.application.model.Orders;

import java.util.List;

public interface OrdersInterface {
    List<Orders> getAllOrders();
}

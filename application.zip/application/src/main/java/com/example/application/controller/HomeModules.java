package com.example.application.controller;

import com.example.application.utils.NavigationManager;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;

public class HomeModules {

    @FXML
    public void gestionStock(ActionEvent actionEvent) {
        NavigationManager.openNewWindow("/gestionStocks/homeGestionStocksView.fxml", "Gestion des stocks");
    }

    @FXML
    public void gestionInventaire(ActionEvent actionEvent) {
        NavigationManager.openNewWindow( "/gestionInventaire/inventoryView.fxml", "Gestion de l'inventaire");
    }

    @FXML
    public void cmdFournisseurEtClient(ActionEvent actionEvent) {
        NavigationManager.openNewWindow( "/cmdFournisseurClient/usersCommandsView.fxml", "Gestion de l'inventaire");
    }

}